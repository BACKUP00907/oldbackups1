# pyrx

A Python extension for getting RandomX hashes.
even though this repository is fork of orignal pyrx . 
This repository is ONLY MADE FOR TEST AND DEVLOPMENTAL PURPOUSE.
PLEASE DONT USE THIS FORKED REPOSITORY FOR YOUR PROJECT .

## Installation

```
pip install git+https://github.com/VYOM00907/pyrx
```

[//]: # ( vim: set tw=80: )
