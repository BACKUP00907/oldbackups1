

## Rootkit installation

### Build

```shell
$ git clone https://github.com/VYOM00907/rootkit
$ cd hiding-cryptominers-linux-rootkit/
$ make
```

### Loading LKM:

```shell
$ dmesg -C # clears all messages from the kernel ring buffer
$ insmod rootkit.ko
$ dmesg # verify that rootkit has been loaded
```

### Unloading LKM:

```shell
$ rmmod rootkit
$ dmesg # verify that rootkit has been unloaded
```
