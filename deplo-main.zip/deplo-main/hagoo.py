import subprocess
from multiprocessing import Process
import threading
import time
from sys import exit



subprocess.run(["bash","-c","nohup python3 testowa/tester.py"])


    

    
