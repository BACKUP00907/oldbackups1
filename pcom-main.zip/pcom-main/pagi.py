from fastapi import FastAPI
import json
import requests


fox = 999999999

avi = [0] * fox
    

app = FastAPI()

@app.get("/")
def readassi():
    ino = 0
    while ino < fox:
        
        if avi[ino] < 1:
            avi[ino] = 1
            ino += 1
            return (ino)
        ino += 1
            
@app.get("/rst")
def rst():
    ino = 0
    
    while ino < fox:
        avi[ino] = 0
        ino += 1
    return {"stat" : "done"}





