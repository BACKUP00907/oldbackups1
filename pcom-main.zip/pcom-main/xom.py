from fastapi import FastAPI
import json
import requests
from multiprocessing import Process
import _thread
import time 



#genral
fox = 999999
#assigner
avi = [0] * fox
#lookup
al = [0] * fox

#api
app = FastAPI()

@app.get("/")
def readassi():
    ino = 0
    while ino < fox:
        
        if avi[ino] < 1:
            avi[ino] = 1
            ino += 1
            return (ino)
        ino += 1
            
@app.get("/rst")
def rst():
    ino = 0
    
    while ino < fox:
        avi[ino] = 0
        ino += 1
    return {"stat" : "done"}



def hla():
    ino = 0
    while ino < fox:
        
        if avi[ino] < 1:
            ino += 1
            return (ino)
        ino += 1


#lookup api 
@app.get("/kal/{wox}")
async def kal(wox: int):
    
    al[int(wox) - 1] = 1
    return str(al[:])


@app.get("/stats")
def stox():

    xob = ""

    lx = hla() + 1


    while lx > -1:
        if al[lx] > 0 :
            xob = xob + "worker" + str(lx + 1) + " is alive\n"
            
        lx = lx - 1
    return xob







def lcle(al):
    while 1==1: 
        
        lx = hla() + 1
        while lx > -2:
            al[lx] = 0     
            lx -= 1
            print("dox")
        time.sleep(300)
            
        


#p = Process(target=lcle, args=(al,))
#p.start()
_thread.start_new_thread(lcle, (al,))




    
    

    




    
