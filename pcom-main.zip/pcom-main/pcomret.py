from fastapi import FastAPI
import json
import requests


series = [
"nord"






]



def fetd():
    data = requests.get("https://api.moneroocean.stream/miner/49FrBm432j9fg33N8PrwSiSig7aTrxZ1wY4eELssmkmeESaYzk2fPkvfN7Kj4NHMfH11NuhUAcKc5DkP7jZQTvVGUnD243g/chart/hashrate/allWorkers")
    rd = json.loads(data.text)
    

app = FastAPI()

@app.get("/")
def read_root():
    
    return x
